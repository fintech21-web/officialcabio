
// Configuration
const finalMessage = "Congratulations, your fingers have been collected. Your Code is: ";
const fixedCode = "LOL-X7A93-J1P22";

// Finger names
const fingerNames = [
  "Left Thumb","Left Index","Left Middle","Left Ring","Left Little",
  "Right Thumb","Right Index","Right Middle","Right Ring","Right Little"
];

const fingersContainer = document.getElementById('fingers');
const bar = document.getElementById('bar');
const scannedCountEl = document.getElementById('scannedCount');
const statusText = document.getElementById('statusText');
const submitBtn = document.getElementById('submitBtn');
const resetBtn = document.getElementById('resetBtn');
const finalPanel = document.getElementById('finalPanel');
const finalCodeEl = document.getElementById('finalCode');
const bigStatus = document.getElementById('bigStatus');
const muted = document.getElementById('muted');

let scanned = new Array(10).fill(false);
let scanning = false;

// Build finger items
fingerNames.forEach((name,i) => {
  const el = document.createElement('div');
  el.className = 'finger';
  el.id = 'finger-' + i;
  el.tabIndex = 0;
  el.innerHTML = `<div class="icon">🔒</div><div class="flabel">${name.split(' ')[1]}</div>`;
  el.addEventListener('click', () => triggerScan(i));
  el.addEventListener('keydown', (e) => { if(e.key==='Enter') triggerScan(i);});
  fingersContainer.appendChild(el);
});

function playBeep() {
  const a = document.getElementById('beep-audio');
  if(a && a.play) { a.currentTime = 0; a.play().catch(()=>{}); }
}
function playScan() {
  const a = document.getElementById('scan-audio');
  if(a && a.play) { a.currentTime = 0; a.play().catch(()=>{}); }
}

function triggerScan(index){
  if(scanned[index] || scanning) return;
  scanning = true;
  statusText.textContent = 'Scanning ' + fingerNames[index];
  bigStatus.textContent = 'Scanning';
  playScan();
  const el = document.getElementById('finger-' + index);
  el.classList.add('scanning');
  setTimeout(() => {
    scanned[index] = true;
    el.classList.add('scanned');
    el.classList.remove('scanning');
    playBeep();
    updateProgress();
    scanning = false;
  }, 700 + Math.random()*400);
}

function updateProgress(){
  const count = scanned.filter(Boolean).length;
  scannedCountEl.textContent = count + ' / 10 scanned';
  const pct = Math.round((count/10)*100);
  bar.style.width = pct + '%';
  if(count === 10){
    statusText.textContent = 'All fingers scanned';
    bigStatus.textContent = 'Ready to Submit';
    muted.textContent = 'Tap Submit to complete (entertainment)';
    submitBtn.disabled = false;
  } else {
    submitBtn.disabled = true;
    statusText.textContent = (count===0)?'Ready':'Scanning...';
    muted.textContent = 'Scan ' + (10-count) + ' more finger(s)';
    bigStatus.textContent = 'Scanning';
  }
}

resetBtn.addEventListener('click', () => {
  scanned = new Array(10).fill(false);
  for(let i=0;i<10;i++){
    const el = document.getElementById('finger-' + i);
    el.classList.remove('scanned');
  }
  bar.style.width = '0%';
  finalPanel.classList.remove('show');
  finalCodeEl.textContent = '';
  updateProgress();
  statusText.textContent = 'Ready';
  bigStatus.textContent = 'Ready to Scan';
  muted.textContent = 'Scan 10 fingers to continue';
});

submitBtn.addEventListener('click', () => {
  if(scanned.filter(Boolean).length < 10) return;
  submitBtn.disabled = true;
  statusText.textContent = 'Submitting...';
  muted.textContent = 'Contacting the Totally-Not-Official servers...';
  playScan();
  let t=0;
  const seq = setInterval(()=> {
    t++;
    if(t>6){
      clearInterval(seq);
      finalPanel.classList.add('show');
      finalCodeEl.textContent = fixedCode;
      bigStatus.textContent = finalMessage + fixedCode;
      muted.textContent = 'This is a harmless prank for entertainment only.';
      const a = document.getElementById('beep-audio'); if(a) a.play().catch(()=>{});
    }
  },180);
});

// Initialize UI
updateProgress();
